package top.hhxs2025.shilou;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

/** 格律校验（平水韵） */
public class CheckActivity extends Activity {

    private EditText etText;
    private Button btnCheck;
    private TextView tvResult;
    private Activity self;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);
        self = this;
        etText = findViewById(R.id.et_text);
        btnCheck = findViewById(R.id.btn_check);
        tvResult = findViewById(R.id.tv_result);
        btnCheck.setOnClickListener(v -> check());
    }

    private void check() {
        final String text = etText.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "请输入诗句", Toast.LENGTH_SHORT).show();
            return;
        }
        btnCheck.setEnabled(false);
        new Thread(() -> {
            String err = null;
            JSONObject data = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("text", text);
                data = Http.api(self, "POST", "/api/check", payload).optJSONObject("data");
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            final JSONObject fData = data;
            runOnUiThread(() -> {
                btnCheck.setEnabled(true);
                if (fErr != null) {
                    Toast.makeText(self, fErr, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (fData == null) {
                    Toast.makeText(self, "校验失败", Toast.LENGTH_SHORT).show();
                    return;
                }
                tvResult.setText(formatResult(fData));
                tvResult.setVisibility(TextView.VISIBLE);
            });
        }).start();
    }

    private String formatResult(JSONObject data) {
        StringBuilder sb = new StringBuilder();
        JSONArray lines = data.optJSONArray("lines");
        if (lines != null) {
            for (int i = 0; i < lines.length(); i++) {
                JSONObject line = lines.optJSONObject(i);
                if (line == null) continue;
                StringBuilder tones = new StringBuilder();
                JSONArray chars = line.optJSONArray("chars");
                if (chars != null) {
                    for (int j = 0; j < chars.length(); j++) {
                        JSONObject ch = chars.optJSONObject(j);
                        if (ch != null) {
                            tones.append(ch.optString("tone", "？")).append(' ');
                        }
                    }
                }
                sb.append("第 ").append(i + 1).append(" 句（").append(line.optInt("length", 0))
                        .append(" 字）：").append(line.optString("line", "")).append('\n');
                sb.append("平仄：").append(tones.toString().trim()).append('\n');
                sb.append("句脚：").append(line.optString("last_char", ""))
                        .append("（").append(line.optString("last_tone", "？")).append(" / ")
                        .append(line.optString("last_rhyme", "未知")).append("）\n\n");
            }
        }
        sb.append(data.optString("conclusion", ""));
        return sb.toString();
    }
}
