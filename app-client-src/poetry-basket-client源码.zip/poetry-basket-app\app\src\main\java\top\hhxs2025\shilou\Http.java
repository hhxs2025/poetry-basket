package top.hhxs2025.shilou;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** 诗篓服务端 HTTP 访问封装 */
public class Http {

    public static class Result {
        public int httpCode;
        public String body;

        public boolean networkOk() {
            return httpCode >= 200 && httpCode < 300;
        }
    }

    private static final String DEFAULT_SERVER = "https://pb.hhxs2025.top";

    public static String baseUrl(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("shilou", Context.MODE_PRIVATE);
        String s = sp.getString("server", DEFAULT_SERVER);
        if (s == null) s = DEFAULT_SERVER;
        s = s.trim();
        while (s.endsWith("/")) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    public static void saveServer(Context ctx, String url) {
        ctx.getSharedPreferences("shilou", Context.MODE_PRIVATE)
                .edit().putString("server", url.trim()).apply();
    }

    public static Result request(Context ctx, String method, String path, JSONObject payload) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(baseUrl(ctx) + path).openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(20000);
        conn.setRequestProperty("Accept", "application/json");
        if (payload != null) {
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            OutputStream os = conn.getOutputStream();
            os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            reader.close();
        }
        conn.disconnect();
        Result result = new Result();
        result.httpCode = code;
        result.body = sb.toString().trim();
        return result;
    }

    /** 返回服务端 JSON，失败时抛异常（msg 带在异常里） */
    public static JSONObject api(Context ctx, String method, String path, JSONObject payload) throws Exception {
        Result r = request(ctx, method, path, payload);
        JSONObject json;
        try {
            json = new JSONObject(r.body);
        } catch (Exception e) {
            throw new Exception("服务端返回异常（HTTP " + r.httpCode + "）");
        }
        if (json.optInt("code", -1) != 0) {
            String msg = json.optString("msg", "请求失败");
            if (json.optInt("code", -1) == 401) {
                msg = "登录已失效，请重新登录";
            }
            throw new Exception(msg);
        }
        return json;
    }

    /** 下载二进制内容（正文配图），需要登录的地址会自动带上会话 Cookie */
    public static byte[] bytes(Context ctx, String pathOrUrl) throws Exception {
        String url = pathOrUrl.startsWith("http") ? pathOrUrl : baseUrl(ctx) + pathOrUrl;
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(20000);
        int code = conn.getResponseCode();
        if (code < 200 || code >= 300) {
            String msg = "HTTP " + code;
            try {
                BufferedReader er = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
                StringBuilder eb = new StringBuilder();
                String l;
                while ((l = er.readLine()) != null) {
                    eb.append(l);
                }
                er.close();
                JSONObject j = new JSONObject(eb.toString());
                if (j.has("msg")) msg = j.optString("msg");
            } catch (Exception ignore) {
            }
            conn.disconnect();
            throw new Exception(msg);
        }
        InputStream is = conn.getInputStream();
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) {
            bos.write(buf, 0, n);
        }
        is.close();
        conn.disconnect();
        return bos.toByteArray();
    }

    /** 上传图片，返回服务端文件名；失败抛异常 */
    public static String uploadImage(Context ctx, byte[] data, String filename, String mime) throws Exception {
        String boundary = "----shilou" + System.currentTimeMillis();
        if (mime == null || mime.isEmpty()) {
            mime = "image/jpeg";
        }
        HttpURLConnection conn = (HttpURLConnection) new URL(baseUrl(ctx) + "/api/upload").openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(60000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        String head = "--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"file\"; filename=\"" + filename + "\"\r\n"
                + "Content-Type: " + mime + "\r\n\r\n";
        bos.write(head.getBytes(StandardCharsets.UTF_8));
        bos.write(data);
        bos.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));

        OutputStream os = conn.getOutputStream();
        os.write(bos.toByteArray());
        os.flush();
        os.close();

        int code = conn.getResponseCode();
        InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();
        }
        conn.disconnect();

        JSONObject json;
        try {
            json = new JSONObject(sb.toString());
        } catch (Exception e) {
            throw new Exception("上传失败（HTTP " + code + "）");
        }
        if (json.optInt("code", -1) != 0) {
            throw new Exception(json.optString("msg", "上传失败"));
        }
        String name = json.optString("filename", "");
        if (name.isEmpty()) {
            throw new Exception("上传失败：服务端未返回文件名");
        }
        return name;
    }
}
