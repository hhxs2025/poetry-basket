package top.hhxs2025.shilou;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/** 诗稿详情页，正文按 HTML 渲染并显示配图 */
public class DetailActivity extends Activity {

    private long poemId = -1;
    private JSONObject poem;
    private TextView tvTitle, tvMeta, tvContent, tvAnnotation, tvAppreciation, tvExtra;
    private Activity self;
    private final Map<String, Bitmap> images = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        self = this;
        poemId = getIntent().getLongExtra("id", -1);
        tvTitle = findViewById(R.id.tv_title);
        tvMeta = findViewById(R.id.tv_meta);
        tvContent = findViewById(R.id.tv_content);
        tvAnnotation = findViewById(R.id.tv_annotation);
        tvAppreciation = findViewById(R.id.tv_appreciation);
        tvExtra = findViewById(R.id.tv_extra);
    }

    @Override
    protected void onResume() {
        super.onResume();
        load();
    }

    private int contentWidth() {
        int screen = getResources().getDisplayMetrics().widthPixels;
        int padding = (int) (getResources().getDisplayMetrics().density * 52);
        int width = screen - padding;
        return width > 200 ? width : screen;
    }

    private void load() {
        final Activity activity = this;
        new Thread(() -> {
            String err = null;
            JSONObject fresh = null;
            Map<String, Bitmap> imgs = new HashMap<>();
            try {
                fresh = Http.api(activity, "GET", "/api/poem/" + poemId, null).optJSONObject("data");
                if (fresh != null) {
                    imgs.putAll(HtmlRender.preload(activity, fresh.optString("content", "")));
                    imgs.putAll(HtmlRender.preload(activity, fresh.optString("annotation", "")));
                    imgs.putAll(HtmlRender.preload(activity, fresh.optString("appreciation", "")));
                }
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            final JSONObject fPoem = fresh;
            final Map<String, Bitmap> fImgs = imgs;
            runOnUiThread(() -> {
                if (fErr != null) {
                    Toast.makeText(self, fErr, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (fPoem == null) {
                    Toast.makeText(self, "未找到该诗稿", Toast.LENGTH_SHORT).show();
                    return;
                }
                poem = fPoem;
                images.clear();
                images.putAll(fImgs);
                render();
            });
        }).start();
    }

    private void render() {
        setTitle(poem.optString("title", "详情"));
        tvTitle.setText(poem.optString("title", ""));

        String dynasty = poem.optString("dynasty", "");
        String genre = poem.optString("genre", "诗");
        String type = poem.optString("type", "收录");
        StringBuilder meta = new StringBuilder();
        meta.append(poem.optString("author", ""));
        if (!dynasty.isEmpty()) meta.append("　").append(dynasty);
        if (!genre.isEmpty()) meta.append("　").append(genre);
        meta.append("　").append(type.equals("原创") ? "原创" : "收录");
        tvMeta.setText(meta.toString());

        tvContent.setText(HtmlRender.toSpanned(poem.optString("content", ""), images, contentWidth()));
        setBlock(tvAnnotation, "笺注", poem.optString("annotation", ""));
        setBlock(tvAppreciation, "赏析", poem.optString("appreciation", ""));

        StringBuilder extra = new StringBuilder();
        String tags = poem.optString("tags", "");
        if (!tags.isEmpty()) {
            extra.append("主题：").append(tags.replace(",", " · ")).append("\n");
        }
        String created = poem.optString("created_at", "");
        if (created.length() > 10) created = created.substring(0, 10);
        extra.append("录入：").append(poem.optString("display_name", "")).append("　").append(created);
        tvExtra.setText(extra.toString());
    }

    private void setBlock(TextView view, String label, String value) {
        if (value == null || value.trim().isEmpty()) {
            view.setVisibility(TextView.GONE);
            return;
        }
        view.setVisibility(TextView.VISIBLE);
        String text = value.trim();
        boolean plain = !text.contains("<") && !text.contains("&");
        if (plain) {
            view.setText(label + "：\n" + text);
        } else {
            CharSequence body = HtmlRender.toSpanned(text, images, contentWidth());
            view.setText(android.text.TextUtils.concat(label + "：\n", body));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_edit) {
            Intent it = new Intent(this, EditActivity.class);
            it.putExtra("id", poemId);
            startActivity(it);
            return true;
        }
        if (id == R.id.action_delete) {
            new AlertDialog.Builder(this)
                    .setTitle("删除确认")
                    .setMessage("确定删除《" + poem.optString("title", "") + "》吗？此操作不可恢复。")
                    .setPositiveButton("删除", (dialog, which) -> doDelete())
                    .setNegativeButton("取消", null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void doDelete() {
        final Activity activity = this;
        new Thread(() -> {
            String err = null;
            try {
                Http.api(activity, "DELETE", "/api/poem/" + poemId, null);
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            runOnUiThread(() -> {
                if (fErr != null) {
                    Toast.makeText(self, fErr, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(self, "已删除", Toast.LENGTH_SHORT).show();
                    finish();
                }
            });
        }).start();
    }
}
