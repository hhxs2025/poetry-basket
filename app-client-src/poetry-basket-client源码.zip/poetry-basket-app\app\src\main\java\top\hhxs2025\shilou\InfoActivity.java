package top.hhxs2025.shilou;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/** 隐私政策 / 用户协议 / 关于我们 */
public class InfoActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        String type = getIntent().getStringExtra("type");
        if (type == null) type = "about";

        String title;
        String asset;
        if ("privacy".equals(type)) {
            title = "隐私政策";
            asset = "privacy.txt";
        } else if ("terms".equals(type)) {
            title = "用户协议";
            asset = "terms.txt";
        } else {
            title = "关于我们";
            asset = "about.txt";
        }
        setTitle(title);
        TextView body = findViewById(R.id.tv_body);
        String text = readAsset(asset);
        if ("about".equals(type)) {
            text = fillAbout(text);
        }
        body.setText(text);
    }

    private String readAsset(String name) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(getAssets().open(name), "UTF-8"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (Exception e) {
            return "内容读取失败：" + e.getMessage();
        }
        return sb.toString().trim();
    }

    private String fillAbout(String text) {
        String versionName = "";
        int versionCode = 0;
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            versionName = info.versionName;
            versionCode = info.versionCode;
        } catch (Exception ignore) {
        }
        return text.replace("__VERSION__", versionName)
                .replace("__CODE__", String.valueOf(versionCode));
    }
}
