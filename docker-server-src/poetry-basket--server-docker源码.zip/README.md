# 诗篓服务端 Docker 部署包

面向阿里云轻量应用服务器，单机多容器部署；`nginx-proxy` 独占宿主机 80 / 443 / 8888，业务容器只监听容器内网端口。

- 访问地址：`https://pb.hhxs2025.top`（443）；`https://pb.hhxs2026.top:8888` 仅作旧版客户端兼容保留
- 镜像地址：`ccr.ccs.tencentyun.com/hhxs2025/poetry-basket:1.0.0`
- 数据目录：宿主机 `./data` 挂载到容器 `/data`（含 `poetry.db`、`users.json`、`app_update.json`、`uploads/`、`backups/`）

## 目录说明

```
Dockerfile                  Python 3.11 + Flask + Waitress 镜像定义
docker-compose.yml          诗篓 + nginx 反向代理（443 主地址 + 8888 旧客户端兼容）
.env.example                密钥模板，复制为 .env 后修改
build-and-push.sh           在飞牛上构建并推送镜像到腾讯云 CCR
deploy-server.sh            在阿里云服务器上拉镜像并启动
nginx/conf.d/default.conf   域名分流、HTTPS 终止、反代 8000
certs/                      放 fullchain.pem 与 privkey.pem
server/app.py               服务端主程序（含更新配置、备份恢复接口）
server/requirements.txt     依赖
ui/                         诗篓网页端（首页/录诗/编辑/详情/格律/登录/注册/admin 后台）
```

## 一、飞牛上构建并推送镜像

```bash
docker login ccr.ccs.tencentyun.com
bash build-and-push.sh
```

> 若在飞牛本机直接跑容器调试，可把 compose 里的 `# build: .` 取消注释，用 `docker compose up -d --build`。

## 二、服务器准备

1. 安全组放行 `22 / 80 / 443 / 8888`。
2. 域名 `pb.hhxs2025.top` A 记录指向服务器公网 IP（`pb.hhxs2026.top` 如继续兼容旧客户端也保持解析）。
3. 证书放到 `certs/fullchain.pem`、`certs/privkey.pem`（需覆盖该域名；阿里云免费证书或 Let's Encrypt 均可）。

```bash
cp .env.example .env
# 修改 POETRY_SECRET_KEY、POETRY_ADMIN_PASSWORD
docker login ccr.ccs.tencentyun.com
bash deploy-server.sh
```

启动后访问 `https://pb.hhxs2025.top`，默认账号 `admin`，密码为 `.env` 里的 `POETRY_ADMIN_PASSWORD`。**首次登录后请立即改掉默认密码。**

## 二之一、宝塔面板部署（推荐：服务器已跑宝塔时用这个）

服务器上如果已经用宝塔面板跑了网站/容器，宝塔的 nginx 占用着宿主机 80/443，**不要再用 `deploy-server.sh`（会端口冲突）**，改用本目录的 `docker-compose-baota.yml`——它不带 nginx，诗篓只监听本机 `127.0.0.1:8000`，由宝塔的 nginx 做反向代理和 HTTPS。

步骤：

1. **上传**整个 `poetry-basket-docker` 目录到服务器（如 `/www/poetry-basket`），`cp .env.example .env` 并改好 `POETRY_SECRET_KEY`、`POETRY_ADMIN_PASSWORD`。
2. **确认 8000 端口空闲**：宝塔终端执行 `ss -tlnp | grep :8000`，没输出即可；被占用就把 compose 里的 `"127.0.0.1:8000:8000"` 改成别的端口（如 8001），后面反代目标同步改。
3. **启动容器**：
   ```bash
   cd /www/poetry-basket
   docker compose -f docker-compose-baota.yml up -d
   docker logs -f poetry-basket   # 看到 Running on http://0.0.0.0:8000 即成功
   ```
4. **宝塔添加网站**：网站 → 添加站点，域名填 `pb.hhxs2025.top`，根目录随便（纯占位，不用建文件）。
5. **申请证书**：站点设置 → SSL → Let's Encrypt 申请证书 → 开启「强制 HTTPS」。
6. **添加反向代理**：站点设置 → 反向代理 → 添加反向代理，目标 URL 填 `http://127.0.0.1:8000`，发送域名 `$host`。
7. **放宽上传限制**（图片/APK/备份恢复可能超过默认 1MB）：站点设置 → 配置文件，在 `server` 块里加一行：
   ```nginx
   client_max_body_size 200m;
   ```
   然后重载 nginx。
8. **阿里云安全组**放行 80 / 443（宝塔系统防火墙也放行）。

完成后访问 `https://pb.hhxs2025.top` 验证；客户端「检查更新」「上传 APK」的直链同样走这个域名，无需任何额外端口。

> 与标准部署（二）的差别：没有 `nginx-proxy` 容器、不用 8888 端口、证书由宝塔管理。旧版客户端（内置 pb.hhxs2026.top:8888 地址）在这种方式下无法继续使用，装一次 1.3.2+ 的新包即可。

## 二之二、账号与注册

- 网页 `/register` 与客户端「注册」入口都走 `POST /api/register`：账号需字母开头、3-20 位字母数字下划线，密码至少 6 位，注册后自动登录。
- `.env` 里 `ALLOW_REGISTER=0` 可关闭自助注册，之后只能由管理员在 `/admin` 添加账号（账号上限 `MAX_USERS`，默认 200）。
- 管理员可在 `/admin` 查看所有注册用户、重置密码、调整角色。

## 三、管理后台（/admin）

- **应用更新**：填写版本号、版本名、APK 直链、更新说明、是否强制更新；也可直接上传 APK，系统自动生成直链。
- **数据备份与恢复**：一键下载 zip 备份；上传备份可恢复，恢复前自动在 `data/backups/` 存一份 `pre-restore-*` 快照（保留最近 20 份）。
- 公开接口 `GET /api/app/version` 供客户端检查更新；`GET /download/<文件名>` 供下载 APK。

## 四、注意事项

- 备份包含全部诗稿与图片，建议定期下载到本地留档；恢复会覆盖线上数据。
- `data/` 与 `certs/` 不要删，重建容器不影响数据。
- 新增其他应用时，只给它 `expose` 端口并接入 `web` 网络，再在 `nginx/conf.d` 加 server 块；不要让新容器占用宿主机 80/443。

## 五、客户端

Android 客户端 1.3.1 已内置 `https://pb.hhxs2025.top`，安装后可直接注册新账号或登录。

- 新建/编辑支持换行排版、居中/左/右对齐、插入配图（上传后自动写入正文 HTML）、预览。
- 详情页按 HTML 渲染正文并显示配图，列表标「图文」的诗稿含图片。
- 服务端「应用更新」里填的版本号大于客户端当前 versionCode（当前为 3）时，客户端才会提示更新。
