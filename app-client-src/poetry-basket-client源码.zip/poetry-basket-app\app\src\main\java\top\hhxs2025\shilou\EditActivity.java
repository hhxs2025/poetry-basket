package top.hhxs2025.shilou;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** 新建 / 编辑诗稿：支持换行排版、对齐、配图与预览 */
public class EditActivity extends Activity {

    private static final int REQ_PICK_IMAGE = 1001;
    private static final int MAX_IMAGE_BYTES = 6 * 1024 * 1024;

    private long poemId = -1;
    private EditText etTitle, etAuthor, etDynasty, etGenre, etTags, etContent, etAnnotation, etAppreciation;
    private TextView tvHint;
    private Spinner spType;
    private Button btnSave;
    private Activity self;
    private String currentType = "收录";
    private int imageCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        self = this;
        poemId = getIntent().getLongExtra("id", -1);
        setTitle(poemId > 0 ? "编辑诗稿" : "新建诗稿");

        etTitle = findViewById(R.id.et_title);
        etAuthor = findViewById(R.id.et_author);
        etDynasty = findViewById(R.id.et_dynasty);
        etGenre = findViewById(R.id.et_genre);
        etTags = findViewById(R.id.et_tags);
        etContent = findViewById(R.id.et_content);
        etAnnotation = findViewById(R.id.et_annotation);
        etAppreciation = findViewById(R.id.et_appreciation);
        tvHint = findViewById(R.id.tv_content_hint);
        spType = findViewById(R.id.sp_type);
        btnSave = findViewById(R.id.btn_save);

        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new String[]{"收录", "原创"});
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spType.setAdapter(typeAdapter);
        spType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentType = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        findViewById(R.id.btn_center).setOnClickListener(v -> wrapAlign("center"));
        findViewById(R.id.btn_left).setOnClickListener(v -> wrapAlign("left"));
        findViewById(R.id.btn_right).setOnClickListener(v -> wrapAlign("right"));
        findViewById(R.id.btn_hr).setOnClickListener(v -> insertAtCursor("\n<hr>\n"));
        findViewById(R.id.btn_image).setOnClickListener(v -> pickImage());
        findViewById(R.id.btn_preview).setOnClickListener(v -> preview());

        if (poemId > 0) {
            loadExisting();
        } else {
            tvHint.setText("提示：一行一句，直接回车换行；插图后保存即可在详情页看到图片。");
        }
        btnSave.setOnClickListener(v -> save());
    }

    // ============================================================
    // 排版工具
    // ============================================================
    private void insertAtCursor(String text) {
        int start = Math.max(etContent.getSelectionStart(), 0);
        int end = Math.max(etContent.getSelectionEnd(), start);
        etContent.getText().replace(start, end, text);
    }

    /** 给选中内容（未选中则为整篇）套一层对齐容器 */
    private void wrapAlign(String align) {
        Editable editable = etContent.getText();
        String all = editable.toString();
        if (all.trim().isEmpty()) {
            toast("请先输入正文");
            return;
        }
        int start = etContent.getSelectionStart();
        int end = etContent.getSelectionEnd();
        if (start < 0 || end < 0) {
            start = 0;
            end = all.length();
        }
        String target;
        if (start == end || all.substring(start, end).trim().isEmpty()) {
            start = 0;
            end = all.length();
            target = all;
        } else {
            target = all.substring(start, end);
        }
        String label = "center".equals(align) ? "居中" : ("right".equals(align) ? "右对齐" : "左对齐");
        String wrapped = "<div style=\"text-align:" + align + "\">\n" + target + "\n</div>";
        editable.replace(start, end, wrapped);
        updateHint("已设为" + label);
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(intent, "选择图片"), REQ_PICK_IMAGE);
        } catch (Exception e) {
            toast("没有可用的图片选择器");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_IMAGE || resultCode != RESULT_OK || data == null) {
            return;
        }
        final Uri uri = data.getData();
        if (uri == null) {
            return;
        }
        updateHint("图片上传中…");
        new Thread(() -> {
            String err = null;
            String filename = null;
            try {
                byte[] bytes = readBytes(uri);
                if (bytes == null || bytes.length == 0) {
                    throw new Exception("读取图片失败");
                }
                if (bytes.length > MAX_IMAGE_BYTES) {
                    throw new Exception("图片不能超过 5MB");
                }
                String name = queryName(uri);
                String mime = getContentResolver().getType(uri);
                filename = Http.uploadImage(self, bytes, name, mime);
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            final String fName = filename;
            runOnUiThread(() -> {
                if (fErr != null) {
                    updateHint("");
                    toast(fErr);
                    return;
                }
                insertAtCursor("\n<img src=\"/uploads/" + fName + "\" class=\"md-image\">\n");
                imageCount++;
                updateHint("已插入第 " + imageCount + " 张配图，保存后可在详情页查看");
            });
        }).start();
    }

    private void updateHint(String text) {
        if (tvHint != null) {
            tvHint.setText(text);
        }
    }

    private byte[] readBytes(Uri uri) throws Exception {
        InputStream is = getContentResolver().openInputStream(uri);
        if (is == null) {
            return null;
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) {
            bos.write(buf, 0, n);
        }
        is.close();
        return bos.toByteArray();
    }

    private String queryName(Uri uri) {
        String name = null;
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) {
                    name = cursor.getString(idx);
                }
            }
        } catch (Exception ignore) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        if (name == null || name.trim().isEmpty()) {
            name = "shilou_" + System.currentTimeMillis() + ".jpg";
        }
        if (!name.contains(".")) {
            name = name + ".jpg";
        }
        return name;
    }

    /** 预览当前正文的最终排版效果 */
    private void preview() {
        final String html = etContent.getText().toString().trim();
        if (html.isEmpty()) {
            toast("正文还是空的");
            return;
        }
        updateHint("正在生成预览…");
        new Thread(() -> {
            Map<String, Bitmap> images = HtmlRender.preload(this, html);
            runOnUiThread(() -> {
                updateHint("");
                int width = getResources().getDisplayMetrics().widthPixels
                        - (int) (getResources().getDisplayMetrics().density * 64);
                TextView view = new TextView(this);
                view.setText(HtmlRender.toSpanned(html, images, width));
                view.setTextSize(15);
                view.setLineSpacing(8, 1f);
                view.setPadding(40, 36, 40, 36);
                ScrollView scroll = new ScrollView(this);
                scroll.addView(view);
                new AlertDialog.Builder(this)
                        .setTitle("正文预览")
                        .setView(scroll)
                        .setPositiveButton("返回修改", null)
                        .show();
            });
        }).start();
    }

    // ============================================================
    // 读取与保存
    // ============================================================
    private void loadExisting() {
        final Activity activity = this;
        new Thread(() -> {
            String err = null;
            JSONObject poem = null;
            try {
                poem = Http.api(activity, "GET", "/api/poem/" + poemId, null).optJSONObject("data");
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            final JSONObject fPoem = poem;
            runOnUiThread(() -> {
                if (fErr != null) {
                    toast(fErr);
                    return;
                }
                if (fPoem == null) return;
                etTitle.setText(fPoem.optString("title", ""));
                etAuthor.setText(fPoem.optString("author", ""));
                etDynasty.setText(fPoem.optString("dynasty", ""));
                etGenre.setText(fPoem.optString("genre", "诗"));
                etTags.setText(fPoem.optString("tags", ""));
                etContent.setText(fPoem.optString("content", ""));
                etAnnotation.setText(fPoem.optString("annotation", ""));
                etAppreciation.setText(fPoem.optString("appreciation", ""));
                String type = fPoem.optString("type", "收录");
                spType.setSelection("原创".equals(type) ? 1 : 0);
                tvHint.setText("提示：可用「居中」等按钮调整排版，插图后会自动写入正文");
            });
        }).start();
    }

    private void save() {
        final String title = etTitle.getText().toString().trim();
        final String author = etAuthor.getText().toString().trim();
        final String dynasty = etDynasty.getText().toString().trim();
        final String genre = etGenre.getText().toString().trim();
        final String tags = etTags.getText().toString().trim();
        final String content = etContent.getText().toString().trim();
        final String annotation = etAnnotation.getText().toString().trim();
        final String appreciation = etAppreciation.getText().toString().trim();
        if (title.isEmpty() || author.isEmpty() || content.isEmpty()) {
            toast("标题、作者、正文为必填项");
            return;
        }
        btnSave.setEnabled(false);
        new Thread(() -> {
            String err = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("title", title);
                payload.put("author", author);
                payload.put("dynasty", dynasty);
                payload.put("genre", genre.isEmpty() ? "诗" : genre);
                payload.put("tags", tags);
                payload.put("content", content);
                payload.put("annotation", annotation);
                payload.put("appreciation", appreciation);
                payload.put("type", currentType);
                if (poemId > 0) {
                    Http.api(self, "PUT", "/api/poem/" + poemId, payload);
                } else {
                    Http.api(self, "POST", "/api/poem", payload);
                }
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            runOnUiThread(() -> {
                btnSave.setEnabled(true);
                if (fErr != null) {
                    toast(fErr);
                } else {
                    toast(poemId > 0 ? "已更新" : "已存入诗篓");
                    finish();
                }
            });
        }).start();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
