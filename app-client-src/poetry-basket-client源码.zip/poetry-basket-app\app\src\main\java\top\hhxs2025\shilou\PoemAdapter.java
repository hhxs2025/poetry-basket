package top.hhxs2025.shilou;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 诗稿列表适配器（支持多选导出） */
public class PoemAdapter extends BaseAdapter {

    private final Context context;
    private final List<JSONObject> poems;
    private final LayoutInflater inflater;
    /** 多选模式下的已选诗稿 id；空集合 = 非选择模式 */
    private final Set<Long> selected = new HashSet<>();

    public PoemAdapter(Context context, List<JSONObject> poems) {
        this.context = context;
        this.poems = poems;
        this.inflater = LayoutInflater.from(context);
    }

    public boolean selecting() {
        return !selected.isEmpty();
    }

    public Set<Long> getSelected() {
        return selected;
    }

    public void clearSelection() {
        selected.clear();
        notifyDataSetChanged();
    }

    /** @return true 表示现在是选中状态 */
    public boolean toggle(long id) {
        if (selected.contains(id)) {
            selected.remove(id);
            notifyDataSetChanged();
            return false;
        }
        selected.add(id);
        notifyDataSetChanged();
        return true;
    }

    @Override
    public int getCount() {
        return poems.size();
    }

    @Override
    public Object getItem(int position) {
        return poems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return poems.get(position).optLong("id", -1);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        ViewHolder holder;
        if (view == null) {
            view = inflater.inflate(R.layout.item_poem, parent, false);
            holder = new ViewHolder();
            holder.tvTitle = view.findViewById(R.id.tv_title);
            holder.tvMeta = view.findViewById(R.id.tv_meta);
            holder.tvTags = view.findViewById(R.id.tv_tags);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        JSONObject poem = poems.get(position);
        String type = poem.optString("type", "收录");
        String title = poem.optString("title", "");
        if ("原创".equals(type)) {
            title += "（原创）";
        }
        if (poem.optInt("has_image", 0) == 1) {
            title += "　图文";
        }
        if (selected.contains(poem.optLong("id", -1))) {
            title = "✓ " + title;
        }
        holder.tvTitle.setText(title);
        String meta = poem.optString("author", "") + " · " + poem.optString("dynasty", "")
                + " · " + poem.optString("genre", "诗")
                + " · 录入：" + poem.optString("display_name", "");
        holder.tvMeta.setText(meta);
        String tags = poem.optString("tags", "").replace(",", " · ").replace("，", " · ");
        holder.tvTags.setText(tags);
        holder.tvTags.setVisibility(tags.isEmpty() ? View.GONE : View.VISIBLE);
        return view;
    }

    private static class ViewHolder {
        TextView tvTitle;
        TextView tvMeta;
        TextView tvTags;
    }
}
