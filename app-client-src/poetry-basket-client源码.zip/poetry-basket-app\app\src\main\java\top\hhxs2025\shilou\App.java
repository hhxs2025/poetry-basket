package top.hhxs2025.shilou;

import android.app.Application;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // 让 HttpURLConnection 自动携带诗篓服务端的会话 Cookie
        CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ORIGINAL_SERVER));
    }
}
