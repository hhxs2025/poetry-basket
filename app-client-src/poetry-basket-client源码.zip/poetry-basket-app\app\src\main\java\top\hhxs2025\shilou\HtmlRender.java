package top.hhxs2025.shilou;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Html;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 把服务端保存的 HTML 正文渲染成带图片的富文本。
 * 图片必须在后台线程先下载好，fromHtml 才能同步取到（避免主线程网络请求）。
 */
public class HtmlRender {

    private static final Pattern IMG_SRC = Pattern.compile("<img[^>]+src\\s*=\\s*[\"']([^\"']+)[\"']",
            Pattern.CASE_INSENSITIVE);

    /** 扫描 HTML 里的图片地址并在当前线程下载（调用方需在后台线程） */
    public static Map<String, Bitmap> preload(Context ctx, String html) {
        Map<String, Bitmap> map = new HashMap<>();
        if (html == null || html.isEmpty()) {
            return map;
        }
        Matcher m = IMG_SRC.matcher(html);
        int count = 0;
        while (m.find() && count < 30) {
            String src = m.group(1);
            if (map.containsKey(src)) {
                continue;
            }
            count++;
            try {
                byte[] data = Http.bytes(ctx, src);
                Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
                if (bmp != null) {
                    map.put(src, bmp);
                }
            } catch (Exception ignore) {
                // 单张图片失败不影响正文
            }
        }
        return map;
    }

    /** HTML → 富文本，图片按屏幕宽度等比缩放 */
    public static CharSequence toSpanned(String html, final Map<String, Bitmap> images, final int maxWidthPx) {
        if (html == null) {
            return "";
        }
        if (!html.contains("<") && !html.contains("&")) {
            return html;
        }
        // Html.fromHtml 会吞掉换行，含标签的正文统一换成 <br>
        html = html.replace("\r\n", "\n").replace("\n", "<br>");
        Html.ImageGetter getter = new Html.ImageGetter() {
            @Override
            public Drawable getDrawable(String source) {
                Bitmap bmp = images == null ? null : images.get(source);
                if (bmp == null) {
                    return null;
                }
                Drawable d = new BitmapDrawable(android.content.res.Resources.getSystem(), bmp);
                int w = bmp.getWidth();
                int h = bmp.getHeight();
                if (maxWidthPx > 0 && w > maxWidthPx) {
                    h = (int) (h * (float) maxWidthPx / w);
                    w = maxWidthPx;
                }
                d.setBounds(0, 0, w, h);
                return d;
            }
        };
        if (Build.VERSION.SDK_INT >= 24) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY, getter, null);
        }
        return Html.fromHtml(html, getter, null);
    }
}
