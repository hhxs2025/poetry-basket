package top.hhxs2025.shilou;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

public class LoginActivity extends Activity {

    private EditText etUser, etPass;
    private Button btnLogin;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        etUser = findViewById(R.id.et_user);
        etPass = findViewById(R.id.et_pass);
        btnLogin = findViewById(R.id.btn_login);
        progress = findViewById(R.id.progress);
        btnLogin.setOnClickListener(v -> doLogin());
        findViewById(R.id.tv_register).setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));
    }

    private void doLogin() {
        final String user = etUser.getText().toString().trim();
        final String pass = etPass.getText().toString().trim();
        if (user.isEmpty() || pass.isEmpty()) {
            toast("请填写账号和密码");
            return;
        }
        btnLogin.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        final Activity self = this;
        new Thread(() -> {
            String err = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("username", user);
                payload.put("password", pass);
                Http.api(self, "POST", "/api/login", payload);
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            runOnUiThread(() -> {
                btnLogin.setEnabled(true);
                progress.setVisibility(View.GONE);
                if (fErr == null) {
                    getSharedPreferences("shilou", MODE_PRIVATE)
                            .edit().putString("username", user).apply();
                    startActivity(new Intent(self, MainActivity.class));
                    finish();
                } else {
                    toast(fErr);
                }
            });
        }).start();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
