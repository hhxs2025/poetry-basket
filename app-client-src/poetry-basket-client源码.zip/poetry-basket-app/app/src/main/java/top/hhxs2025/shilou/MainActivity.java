package top.hhxs2025.shilou;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/** 诗稿列表主页 */
public class MainActivity extends Activity {

    private ListView listView;
    private EditText etSearch;
    private TextView tvStats, tvEmpty;
    private final List<JSONObject> poems = new ArrayList<>();
    private final List<JSONObject> allPoems = new ArrayList<>();
    private boolean mineOnly = false;
    private PoemAdapter adapter;
    private String lastKeyword = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.list_poems);
        etSearch = findViewById(R.id.et_search);
        tvStats = findViewById(R.id.tv_stats);
        tvEmpty = findViewById(R.id.tv_empty);
        adapter = new PoemAdapter(this, poems);
        listView.setAdapter(adapter);
        findViewById(R.id.btn_search).setOnClickListener(v -> load(etSearch.getText().toString().trim()));
        listView.setOnItemClickListener((parent, view, position, id) -> {
            JSONObject poem = poems.get(position);
            if (adapter.selecting()) {
                adapter.toggle(poem.optLong("id", -1));
                updateSelectionHint();
                return;
            }
            Intent it = new Intent(this, DetailActivity.class);
            it.putExtra("id", poem.optLong("id", -1));
            startActivity(it);
        });
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            adapter.toggle(poems.get(position).optLong("id", -1));
            updateSelectionHint();
            return true;
        });
        UpdateChecker.check(this, false);
    }

    /** 选择模式下在统计栏提示已选数量 */
    private void updateSelectionHint() {
        int n = adapter.getSelected().size();
        if (n > 0) {
            tvStats.setText("已选 " + n + " 首 · 点右上菜单可导出");
        } else {
            tvStats.setText("");
            load(lastKeyword);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        load(lastKeyword);
    }

    private void load(final String keyword) {
        lastKeyword = keyword;
        tvEmpty.setVisibility(View.GONE);
        final Activity self = this;
        new Thread(() -> {
            String err = null;
            List<JSONObject> fresh = new ArrayList<>();
            String statsText = "";
            try {
                String path = "/api/poems";
                if (!keyword.isEmpty()) {
                    path += "?keyword=" + URLEncoder.encode(keyword, "UTF-8");
                }
                JSONObject resp = Http.api(self, "GET", path, null);
                JSONArray arr = resp.optJSONArray("data");
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        fresh.add(arr.optJSONObject(i));
                    }
                }
                try {
                    JSONObject stats = Http.api(self, "GET", "/api/stats", null).optJSONObject("data");
                    if (stats != null) {
                        statsText = "共 " + stats.optInt("total", 0) + " 首 · 作者 "
                                + stats.optInt("authors", 0) + " 位";
                    }
                } catch (Exception ignore) {
                }
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            final List<JSONObject> fFresh = fresh;
            final String fStats = statsText;
            runOnUiThread(() -> {
                if (fErr != null) {
                    Toast.makeText(self, fErr, Toast.LENGTH_SHORT).show();
                    if (fErr.contains("登录已失效")) {
                        startActivity(new Intent(self, LoginActivity.class));
                        finish();
                    }
                    return;
                }
                allPoems.clear();
                allPoems.addAll(fFresh);
                tvStats.setText(fStats);
                if (adapter.selecting()) {
                    adapter.clearSelection();
                }
                applyFilter();
            });
        }).start();
    }

    /** 「只看我的」本地筛选，不额外请求服务端 */
    private void applyFilter() {
        String me = getSharedPreferences("shilou", MODE_PRIVATE).getString("username", "");
        poems.clear();
        for (JSONObject p : allPoems) {
            if (!mineOnly || (me != null && me.equals(p.optString("user_id", "")))) {
                poems.add(p);
            }
        }
        adapter.notifyDataSetChanged();
        if (poems.isEmpty()) {
            tvEmpty.setText(mineOnly ? "你还没有录入诗稿" : "诗篓还是空的，点右上角「新建」录第一首");
            tvEmpty.setVisibility(View.VISIBLE);
        } else {
            tvEmpty.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    private void openInfo(String type) {
        Intent it = new Intent(this, InfoActivity.class);
        it.putExtra("type", type);
        startActivity(it);
    }

    /** 导出所选诗稿为 Markdown（服务端生成，另存到用户选择的位置） */
    private void exportSelected() {
        java.util.Set<Long> sel = adapter.getSelected();
        if (sel.isEmpty()) {
            Toast.makeText(this, "请先长按诗稿勾选要导出的内容", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder ids = new StringBuilder();
        for (long v : sel) {
            if (ids.length() > 0) ids.append(',');
            ids.append(v);
        }
        String path = "/api/my/export?format=md&ids=" + ids;
        startSave("text/markdown", "诗篓导出.md", path, REQ_EXPORT_MD);
    }

    /** 导出自己的诗稿数据为 SQLite db */
    private void exportMyDb() {
        startSave("application/octet-stream", "shilou-export.db",
                "/api/my/export?format=db", REQ_EXPORT_DB);
    }

    /** 发起系统「另存为」对话框（SAF），不申请存储权限 */
    private void startSave(String mime, String suggestName, String path, int requestCode) {
        android.content.Intent it = new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT);
        it.addCategory(android.content.Intent.CATEGORY_OPENABLE);
        it.setType(mime);
        it.putExtra(android.content.Intent.EXTRA_TITLE, suggestName);
        startActivityForResult(it, requestCode);
        exportPath = path;
    }

    private static final int REQ_EXPORT_MD = 101;
    private static final int REQ_EXPORT_DB = 102;
    private String exportPath;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        final android.net.Uri uri = data.getData();
        final String path = exportPath;
        final boolean isMd = requestCode == REQ_EXPORT_MD;
        final Activity self = this;
        Toast.makeText(this, "正在导出…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String err = null;
            try {
                byte[] bytes = Http.bytes(self, path);
                try (java.io.OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) throw new Exception("无法写入所选位置");
                    os.write(bytes);
                    os.flush();
                }
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            runOnUiThread(() -> {
                if (fErr == null) {
                    Toast.makeText(self, isMd ? "Markdown 已导出" : "数据 db 已导出", Toast.LENGTH_SHORT).show();
                    if (isMd) {
                        adapter.clearSelection();
                        updateSelectionHint();
                    }
                } else {
                    Toast.makeText(self, "导出失败：" + fErr, Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_create) {
            startActivity(new Intent(this, EditActivity.class));
            return true;
        }
        if (id == R.id.action_mine) {
            mineOnly = !mineOnly;
            item.setChecked(mineOnly);
            applyFilter();
            return true;
        }
        if (id == R.id.action_export_md) {
            exportSelected();
            return true;
        }
        if (id == R.id.action_export_db) {
            exportMyDb();
            return true;
        }
        if (id == R.id.action_check) {
            startActivity(new Intent(this, CheckActivity.class));
            return true;
        }
        if (id == R.id.action_update) {
            UpdateChecker.check(this, true);
            return true;
        }
        if (id == R.id.action_privacy) {
            openInfo("privacy");
            return true;
        }
        if (id == R.id.action_terms) {
            openInfo("terms");
            return true;
        }
        if (id == R.id.action_about) {
            openInfo("about");
            return true;
        }
        if (id == R.id.action_logout) {
            final Activity self = this;
            new Thread(() -> {
                try {
                    Http.api(self, "POST", "/api/logout", null);
                } catch (Exception ignore) {
                }
                runOnUiThread(() -> {
                    startActivity(new Intent(self, LoginActivity.class));
                    finish();
                });
            }).start();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
