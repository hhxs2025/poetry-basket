package top.hhxs2025.shilou;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class LoginActivity extends Activity {

    /** flex 渠道 = 可配置服务器 + 记住账号密码；cloud 渠道保持原行为 */
    private static final boolean FLEX = BuildConfig.FLAVOR.equals("flex");

    private EditText etUser, etPass;
    private Button btnLogin;
    private ProgressBar progress;
    private CheckBox cbRemember;
    private TextView tvServer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        etUser = findViewById(R.id.et_user);
        etPass = findViewById(R.id.et_pass);
        btnLogin = findViewById(R.id.btn_login);
        progress = findViewById(R.id.progress);
        cbRemember = findViewById(R.id.cb_remember);
        tvServer = findViewById(R.id.tv_server);
        LinearLayout rowServer = findViewById(R.id.row_server);

        if (!FLEX) {
            // cloud 渠道：不显示服务器地址与记住密码入口
            rowServer.setVisibility(View.GONE);
            cbRemember.setVisibility(View.GONE);
        } else {
            refreshServerText();
            rowServer.setOnClickListener(v -> promptServer());
        }

        // 预填上次登录的账号密码（flex 渠道且勾选过记住）
        if (FLEX) {
            android.content.SharedPreferences sp = getSharedPreferences("shilou", MODE_PRIVATE);
            if (sp.getBoolean("remember", false)) {
                etUser.setText(sp.getString("username", ""));
                etPass.setText(sp.getString("saved_pass", ""));
                cbRemember.setChecked(true);
            }
        }

        btnLogin.setOnClickListener(v -> doLogin());
        findViewById(R.id.tv_register).setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));
    }

    private void refreshServerText() {
        tvServer.setText(Http.baseUrl(this));
    }

    /** 弹窗修改服务器地址，保存后立即生效 */
    private void promptServer() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(Http.baseUrl(this));
        input.setHint("例如 https://pb.hhxs2025.top 或 http://192.168.1.10:8000");
        new AlertDialog.Builder(this)
                .setTitle("服务器地址")
                .setMessage("填服务端的访问地址，含 http(s)://，末尾不带斜杠")
                .setView(input)
                .setPositiveButton("保存", (d, w) -> {
                    String url = input.getText().toString().trim();
                    if (url.isEmpty()) {
                        toast("地址不能为空");
                        return;
                    }
                    if (!url.startsWith("http://") && !url.startsWith("https://")) {
                        toast("地址需以 http:// 或 https:// 开头");
                        return;
                    }
                    Http.saveServer(this, url);
                    // 换服务器后清空旧会话 Cookie，避免拿着旧会话去连新服务器
                    try {
                        java.net.CookieHandler handler = java.net.CookieHandler.getDefault();
                        if (handler instanceof java.net.CookieManager) {
                            ((java.net.CookieManager) handler).getCookieStore().removeAll();
                        }
                    } catch (Exception ignore) {
                    }
                    refreshServerText();
                    toast("服务器已保存");
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void doLogin() {
        final String user = etUser.getText().toString().trim();
        final String pass = etPass.getText().toString().trim();
        if (user.isEmpty() || pass.isEmpty()) {
            toast("请填写账号和密码");
            return;
        }
        btnLogin.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        final Activity self = this;
        new Thread(() -> {
            String err = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("username", user);
                payload.put("password", pass);
                Http.api(self, "POST", "/api/login", payload);
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            runOnUiThread(() -> {
                btnLogin.setEnabled(true);
                progress.setVisibility(View.GONE);
                if (fErr == null) {
                    android.content.SharedPreferences.Editor edit =
                            getSharedPreferences("shilou", MODE_PRIVATE).edit();
                    edit.putString("username", user);
                    if (FLEX && cbRemember.isChecked()) {
                        edit.putBoolean("remember", true);
                        edit.putString("saved_pass", pass);
                    } else {
                        edit.putBoolean("remember", false);
                        edit.remove("saved_pass");
                    }
                    edit.apply();
                    startActivity(new Intent(self, MainActivity.class));
                    finish();
                } else {
                    toast(fErr);
                }
            });
        }).start();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
