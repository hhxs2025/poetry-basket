package top.hhxs2025.shilou;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Environment;
import android.widget.Toast;

import org.json.JSONObject;

/**
 * 检查更新：读取 /api/app/version，比对 versionCode。
 * 发现新版本后用系统 DownloadManager 下载 APK，完成后自动拉起安装；
 * 下载器不可用时回退到浏览器打开直链。
 */
public class UpdateChecker {

    public static void check(final Activity activity, final boolean manual) {
        if (activity == null || activity.isFinishing()) return;
        new Thread(() -> {
            String err = null;
            JSONObject data = null;
            try {
                data = Http.api(activity, "GET", "/api/app/version", null).optJSONObject("data");
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            final JSONObject fData = data;
            activity.runOnUiThread(() -> {
                if (activity.isFinishing()) return;
                if (fErr != null) {
                    if (manual) {
                        String hint = fErr.contains("404") || fErr.contains("异常")
                                ? "服务端不支持在线更新，请先升级服务端镜像" : fErr;
                        Toast.makeText(activity, hint, Toast.LENGTH_SHORT).show();
                    }
                    return;
                }
                if (fData == null) return;
                // 直接比较版本号（如 1.3.2 vs 1.4.0）；版本号异常时回退比较 versionCode
                int latest = fData.optInt("versionCode", 0);
                String latestName = fData.optString("versionName", "");
                int cmp = compareVersions(latestName, currentVersionName(activity));
                boolean hasUpdate = cmp != 0 ? cmp > 0 : latest > currentVersionCode(activity);
                if (!hasUpdate) {
                    if (manual) Toast.makeText(activity, "已是最新版本", Toast.LENGTH_SHORT).show();
                    return;
                }
                showDialog(activity, fData);
            });
        }).start();
    }

    private static String currentVersionName(Context ctx) {
        try {
            PackageInfo info = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            return info.versionName == null ? "" : info.versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** 语义比较 x.y.z 版本号：>0 表示 a 更新，<0 表示 a 更旧，=0 相同；解析失败返回 0 */
    private static int compareVersions(String a, String b) {
        int[] va = parseVersion(a), vb = parseVersion(b);
        if (va == null || vb == null) return 0;
        for (int i = 0; i < 3; i++) {
            if (va[i] != vb[i]) return va[i] > vb[i] ? 1 : -1;
        }
        return 0;
    }

    private static int[] parseVersion(String s) {
        if (s == null || s.isEmpty()) return null;
        String[] parts = s.trim().split("\\.");
        try {
            int[] v = new int[3];
            for (int i = 0; i < 3 && i < parts.length; i++) {
                v[i] = Integer.parseInt(parts[i].trim());
            }
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static int currentVersionCode(Context ctx) {
        try {
            PackageInfo info = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            return info.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private static void showDialog(final Activity activity, JSONObject data) {
        final String url = data.optString("url", "");
        final String versionName = data.optString("versionName", "");
        String notes = data.optString("notes", "");
        boolean force = data.optBoolean("force", false);

        AlertDialog.Builder builder = new AlertDialog.Builder(activity)
                .setTitle("发现新版本 " + versionName)
                .setMessage(notes.isEmpty() ? "建议更新到最新版本。" : notes)
                .setPositiveButton("立即更新", (dialog, which) -> downloadApk(activity, url, versionName));
        if (!force) {
            builder.setNegativeButton("稍后", null);
        }
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(!force);
        dialog.show();
    }

    /** 用系统下载器下载 APK，完成后自动拉起安装界面 */
    private static void downloadApk(final Activity activity, String url, String versionName) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(activity, "服务端尚未配置更新直链", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            DownloadManager dm = (DownloadManager) activity.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) throw new Exception("no download manager");
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url.trim()));
            req.setTitle("诗篓 " + versionName);
            req.setDescription("正在下载新版本安装包");
            req.setMimeType("application/vnd.android.package-archive");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            // 文件名带版本号，避免旧包占用导致下载失败
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    "shilou-" + versionName + ".apk");
            final long id = dm.enqueue(req);

            BroadcastReceiver done = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent intent) {
                    long doneId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                    if (doneId != id) return;
                    try {
                        ctx.unregisterReceiver(this);
                    } catch (Exception ignore) {
                    }
                    installDownloaded(ctx, dm, id);
                }
            };
            activity.getApplicationContext().registerReceiver(done,
                    new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
            Toast.makeText(activity, "开始下载新版本，完成后自动弹出安装", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            openInBrowser(activity, url);
        }
    }

    private static void installDownloaded(Context ctx, DownloadManager dm, long id) {
        try {
            Uri uri = dm.getUriForDownloadedFile(id);
            if (uri == null) throw new Exception("文件不存在");
            Intent it = new Intent(Intent.ACTION_VIEW);
            it.setDataAndType(uri, "application/vnd.android.package-archive");
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(it);
        } catch (Exception e) {
            Toast.makeText(ctx, "下载完成，请在系统通知栏点击「诗篓」通知进行安装", Toast.LENGTH_LONG).show();
        }
    }

    /** 回退：用浏览器打开直链 */
    private static void openInBrowser(Activity activity, String url) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url.trim())));
        } catch (Exception e) {
            Toast.makeText(activity, "无法打开下载链接", Toast.LENGTH_SHORT).show();
        }
    }
}
