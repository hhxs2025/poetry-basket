package top.hhxs2025.shilou;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.regex.Pattern;

/** 注册新账号 */
public class RegisterActivity extends Activity {

    private static final Pattern USERNAME = Pattern.compile("^[A-Za-z][A-Za-z0-9_]{2,19}$");

    private EditText etDisplay, etUser, etPass, etPass2;
    private Button btnRegister;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        etDisplay = findViewById(R.id.et_display);
        etUser = findViewById(R.id.et_user);
        etPass = findViewById(R.id.et_pass);
        etPass2 = findViewById(R.id.et_pass2);
        btnRegister = findViewById(R.id.btn_register);
        progress = findViewById(R.id.progress);
        btnRegister.setOnClickListener(v -> doRegister());
        findViewById(R.id.tv_back_login).setOnClickListener(v -> finish());
    }

    private void doRegister() {
        final String display = etDisplay.getText().toString().trim();
        final String user = etUser.getText().toString().trim();
        final String pass = etPass.getText().toString().trim();
        final String pass2 = etPass2.getText().toString().trim();

        if (!USERNAME.matcher(user).matches()) {
            toast("账号需以字母开头，3-20 位字母、数字或下划线");
            etUser.requestFocus();
            return;
        }
        if (pass.length() < 6) {
            toast("密码至少 6 位");
            etPass.requestFocus();
            return;
        }
        if (!pass.equals(pass2)) {
            toast("两次输入的密码不一致");
            etPass2.requestFocus();
            return;
        }

        btnRegister.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        final Activity self = this;
        new Thread(() -> {
            String err = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("username", user);
                payload.put("password", pass);
                payload.put("display_name", display.isEmpty() ? user : display);
                Http.api(self, "POST", "/api/register", payload);
            } catch (Exception e) {
                err = e.getMessage();
            }
            final String fErr = err;
            runOnUiThread(() -> {
                btnRegister.setEnabled(true);
                progress.setVisibility(View.GONE);
                if (fErr == null) {
                    getSharedPreferences("shilou", MODE_PRIVATE)
                            .edit().putString("username", user).apply();
                    Toast.makeText(self, "注册成功，欢迎使用", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(self, MainActivity.class));
                    finish();
                } else {
                    toast(fErr);
                }
            });
        }).start();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
